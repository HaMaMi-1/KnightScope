"""Analysis package for KnightScope."""
