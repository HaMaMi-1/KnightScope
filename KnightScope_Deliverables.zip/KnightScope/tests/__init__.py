"""Test package for KnightScope."""
