"""Visualization package for KnightScope."""
